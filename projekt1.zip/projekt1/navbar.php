<nav>
            <!-- Logo och meny finns i nav -->
            <ul>
                <a id="current" href="./">Home</a>
                <a href="./">Projekt 1</a>
            <a href="../projekt2/">Projekt 2</a>
            </ul>
    </nav>